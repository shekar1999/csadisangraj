#include <stdio.h>

int main()
{
	printf("This is an example file.\n");
	return 0;
}
