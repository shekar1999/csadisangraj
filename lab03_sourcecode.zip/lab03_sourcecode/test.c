#include <stdio.h>

int main()
{
	printf("This is a test file.\n");
	return 0;
}
